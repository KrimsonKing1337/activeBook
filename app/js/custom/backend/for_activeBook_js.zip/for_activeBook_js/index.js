let sassToCss = require('./sassToCss');
let generateHtml = require('./generateHtml');

//render sass to css
sassToCss();

//render html pages
generateHtml();