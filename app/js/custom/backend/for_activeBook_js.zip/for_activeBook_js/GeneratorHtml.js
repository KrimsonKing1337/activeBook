/**
 * Created by k on 07.05.17.
 */

let fs = require('fs');
let path = require('path');
let appRoot = require('app-root-path');

module.exports = class GeneratorHtml {
    constructor() {

    }

    static _getTemplate(file) {
        return new Promise((resolve, reject) => {
            fs.readFile(file, function (err, data) {
                if (err) throw err;

                return resolve(data.toString());
            });
        });
    }

    /**
     *
     * @param files[] {object}
     */
    static _getPartials(files) {
        const promises = [];

        files.forEach(function (file) {
            promises.push(new Promise((resolve, reject) => {
                fs.readFile(file.fullName, (err, data) => {
                    if (err) throw err;

                    return resolve({
                        fileProps: file,
                        content: data.toString()
                    });
                });
            }));
        });

        return Promise.all(promises);
    }

    /**
     *
     * @param params {object}
     * @param params.rootTemplate {string}
     * @param params.footerTemplate {string}
     * @param params.headerTemplate {string}
     * @param params.partialsDir {string}
     */
    static render(params = {}) {
        let partialFiles;
        let rootTemplate;
        let footerTemplate;
        let headerTemplate;

        GeneratorHtml._getFiles(params.partialsDir)
            .then((files) => {
                partialFiles = files;
                return GeneratorHtml._getTemplate(params.rootTemplate);
            })
            .then((template) => {
                rootTemplate = template;
                return GeneratorHtml._getTemplate(params.footerTemplate);
            })
            .then((template) => {
                footerTemplate = template;
                return GeneratorHtml._getTemplate(params.headerTemplate);
            })
            .then((template) => {
                headerTemplate = template;
                return GeneratorHtml._getPartials(partialFiles);
            })
            .then((partials) => {
                partials.forEach((partial) => {
                    let html = rootTemplate.replace('{%content}', partial.content);
                    html = html.replace('{%header}', headerTemplate);
                    html = html.replace('{%footer}', footerTemplate);

                    debugger;

                    fs.writeFile(appRoot + '/build/' + partial.fileProps.name, html, (err) => {
                        if (err) throw err;
                    });
                });
            })
            .catch((err) => {
                throw err;
            });
    }

    /**
     *
     * @param dir {string}
     */
    static _getFiles(dir) {
        return new Promise((resolve, reject) => {
            fs.readdir(dir, function (err, files) {
                if (err) return reject(err);

                return resolve(files);
            });
        }).then((files) => {
            let filesFullPath = [];

            files.forEach(function (file) {
                filesFullPath.push(dir + file);
            });

            return GeneratorHtml._getFilesProps(filesFullPath);
        });
    }

    static _getFilesProps(files) {
        let filesProps = [];

        files.forEach(function (file) {
           filesProps.push(GeneratorHtml._getFileProps(file));
        });

        return filesProps;
    }

    /**
     *
     * @param file {string}
     * @private
     */
    static _getFileProps(file) {
        let fileProps = {
            name: path.basename(file),
            fullName: file,
            ext: path.extname(file),
            dirPath: path.dirname(file)
        };

        fileProps.nameWithoutExt = path.basename(fileProps.name, fileProps.ext);

        return fileProps;
    }
};