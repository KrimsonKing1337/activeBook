module.exports = generateHtml = () => {
    let appRoot = require('app-root-path');
    let GeneratorHtml = require('./GeneratorHtml');

    let partialsDir = appRoot + '/src/partials/';
    let templatesDir = appRoot + '/src/templates/';

    GeneratorHtml.render({
        rootTemplate: templatesDir + 'htmlRoot.html',
        footerTemplate: templatesDir + 'footer.html',
        headerTemplate: templatesDir + 'header.html',
        partialsDir: partialsDir
    });
};